# Imports
import os
import pandas as pd
import numpy as np

# Determine all files
files = os.listdir()

# Determine all sensors
sensors = []
for file in files:
    if file.endswith(".xml"):
        sensors.append(file.replace(".xml",""))

# Load all sensor data
lst_sensors = []
for sensor in sensors:
    f = open(sensor+".xml", "r")
    content = f.read()
    f.close()
    lines = content.split("\n")
    lines = [line.strip() for line in lines]
    filtered_lines = [line for line in lines if line.startswith("<interval")]
    times = [line.split("begin=\"")[1].split("\"")[0] for line in filtered_lines]
    vehis = [line.split("nVehEntered=\"")[1].split("\"")[0] for line in filtered_lines]
    lst_sensors.append(vehis)
    
# Convert to dataframe
df = pd.DataFrame(np.asarray(list(zip(times, *lst_sensors))), columns=["time", *sensors])
df.to_csv("detectors_summary.csv", index=None)